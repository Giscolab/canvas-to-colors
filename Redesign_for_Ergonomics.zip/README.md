
  # Redesign for Ergonomics

  This is a code bundle for Redesign for Ergonomics. The original project is available at https://www.figma.com/design/hlI9Y867as6PRsK4GfSSKe/Redesign-for-Ergonomics.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  